<?php
/* config.php */
return array(
  'web_title' => 'Office',
  'web_description' => 'ตัวอย่างระบบบันทึกข้อมูลพนักงาน',
  'timezone' => 'Asia/Bangkok',
);
