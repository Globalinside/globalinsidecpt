<?php
/* settings/database.php */
return array(
  'mysql' => array(
    'dbdriver' => 'mysql',
    'username' => 'plus',
    'password' => '1234',
    'dbname' => 'u',
    'prefix' => '',
  ),
  'tables' => array(
    'user' => 'user'
  )
);
